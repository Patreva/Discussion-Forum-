<?php $__env->startSection('content'); ?>
<div class="card">
    <?php echo $__env->make('partials.discussion-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="card-body">
        <div class="text-center"><strong><?php echo e($discussion->title); ?></strong></div>
        <hr>
        <?php echo $discussion->content; ?>

        <?php if($discussion->bestReply): ?>
        <div class="card bg-success">
            <div class="card-header">
      <div class="d-flex justify-content-between">
<div>
    <img width="40px" height="40px" style="border-radius:50%" class="mr-2" src="<?php echo e(Gravatar::src($discussion->bestReply->owner->email)); ?>" alt="">
    <strong><?php echo e($discussion->bestReply->owner->name); ?></strong>
</div>
<div>
    <strong>Best Reply</strong>
</div>
      </div>
            </div>
            <div class="card-body">
                <?php echo $discussion->bestReply->content; ?>

            </div>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php $__currentLoopData = $discussion->replies()->paginate(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
<div class="card my-5">
    <div class="card-header">
        <div>
            <div>
            <img width="40px" height="40px" style="border-radius:50%" src="<?php echo e(Gravatar::src($reply->owner->email)); ?>" alt="">
            <span><?php echo e($reply->owner->name); ?></span>
           </div>
        </div>
      <div class="d-flex justify-content-between">
          
<?php if(auth()->guard()->check()): ?>
<?php if(auth()->user()->id==$discussion->user_id): ?>
<form action="<?php echo e(route('discussions.best-reply' , ['discussion'=>$discussion->slug , 'reply'=>$reply->id])); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <button type="submit" class="btn btn-sm btn-info">mark as best reply</button>
    </form>
    <?php endif; ?>
<?php endif; ?>
      </div>
    </div>

    <div class="card-body">
        <?php echo $reply->content; ?>


        </div>   
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php echo e($discussion->replies()->paginate(3)->links()); ?>



<div class="card">
    <div class="card-header">
        Add Reply
    </div>
    <div class="card-body">
<?php if(auth()->guard()->check()): ?>
    <form action="<?php echo e(route('replies.store', $discussion->slug)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="content" id="content">
    <trix-editor input="content"></trix-editor>
    <button type="submit" class="btn btn-success btn-sm my-2">
        Add Reply
    </button>
</form>
    <?php else: ?>
<a href="<?php echo e(route('login')); ?>" class="btn btn-info">Sign in to add a reply</a>
<?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/trix/1.2.1/trix.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/trix/1.2.1/trix.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laravel-forum\resources\views/discussions/show.blade.php ENDPATH**/ ?>