<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">Add discussion </div>

    <div class="card-body">
        <form action="<?php echo e(route('discussions.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
             <div class="form-group">
                 <label for="title">Title</label>
                 <input type="text" class="form-control" name="title" value="">
             </div>
             <div class="form-group">
                 <label for="content">Content</label>
                 <input id="content" type="hidden" name="content">
                  <trix-editor input="content"></trix-editor>
             </div>
             <div class="form-group">
                 <label for="channel">Channel</label>
                 <select name="channel" id="channel" class="form-control">
                     <?php $__currentLoopData = $channels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $channel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <option value="<?php echo e($channel->id); ?>"><?php echo e($channel->name); ?></option>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 </select>
             </div>
             <button type="submit" class="btn btn-success">Create discussion</button>
            </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/trix/1.2.1/trix.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/trix/1.2.1/trix.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laravel-forum\resources\views/discussions/create.blade.php ENDPATH**/ ?>