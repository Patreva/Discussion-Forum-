<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">Notifications</div>

    <div class="card-body">
        <?php if(session('status')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>

<ul class="list-group">
    <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <li class="list-group-item">
        <?php if($notification->type =='App\Notifications\NewReplyAdded'): ?>
A new reply added to your discussion <strong><?php echo e($notification->data['discussion']['title']); ?></strong>
    <a href="<?php echo e(route('discussions.show', $notification->data['discussion']['slug'])); ?>" class="btn btn-sm btn-info float-right">
        
        View Discussion

    </a>
    <?php endif; ?>
    <?php if($notification->type=='App\Notifications\ReplyMarkedAsBestReply'): ?>

    Your reply to the discussion <strong><?php echo e($notification->data['discussion']['title']); ?></strong> was marked as best reply
    <a href="<?php echo e(route('discussions.show', $notification->data['discussion']['slug'])); ?>" class="btn btn-sm btn-info float-right">
        
        View Discussion

    </a>
        
    <?php endif; ?>
        
    </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laravel-forum\resources\views/users/notifications.blade.php ENDPATH**/ ?>