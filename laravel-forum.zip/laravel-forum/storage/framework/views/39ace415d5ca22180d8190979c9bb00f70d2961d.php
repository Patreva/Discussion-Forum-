<div class="card-header">
    <div class="d-flex justify-content-between">
         <div>
            <img width="40px" height="40px" style="border-radius: 50%" src="<?php echo e(Gravatar::src($discussion->author->email)); ?>" alt="">
            <strong class="ml-2"> <?php echo e($discussion->author->name); ?></strong>
         </div>
         <div>
         <a href="<?php echo e(route('discussions.show', $discussion->slug)); ?>" class="btn btn-success btn-sm">View Conversation</a>
         </div>
    </div>
        </div><?php /**PATH C:\laragon\www\laravel-forum\resources\views/partials/discussion-header.blade.php ENDPATH**/ ?>