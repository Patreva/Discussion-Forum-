<?php

namespace App;

class Channel extends Model
{
    //
}
