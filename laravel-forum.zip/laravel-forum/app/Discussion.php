<?php

namespace App;

use App\Notifications\ReplyMarkedAsBestReply;

class Discussion extends Model
{
    public function author(){
        return $this->belongsTo(User::class, 'user_id');
    }
    public function replies(){
        return $this->hasMany(Reply::class);
    }
    public function getRouteKeyName(){
     return 'slug';
    }
    public function markAsBestReply(Reply $reply){
       $this->update([
           'reply_id'=>$reply->id
       ]);
       if($reply->owner->id==$this->author->id){
           return;
       }
       $reply->owner->notify(new ReplyMarkedAsBestReply($reply->discussion));

    }
    public function bestReply(){
        return $this->belongsTo(Reply::class, 'reply_id');
    }
    public function scopeFilterByChannels($builder){
        if(request()->query('channel')){
              //filter

              //checking the database
                 $channel=Channel::where('slug', request()->query('channel'))->first();
                 //if channel exists in the database 
                 if($channel){
                     return $builder->where('channel_id', $channel->id);
                 }
                 //if channel does not exist in the database 
                 return $builder;
        }
        return $builder;

    }
}
